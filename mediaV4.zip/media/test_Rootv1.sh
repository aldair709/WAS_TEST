#! /bin/bash

sep="###########################################"

#Usuario y archivos temporales
	u=$(whoami)
	userL="$u"

#dtemp="/home/$userL/temp.txt"
	#dtemp="/$userL/temp.txt"

	dtempServ="/home/serv.txt"
	#dtempWAS="/home/was.txt"

	cadenaServ="HOSTNAME, IP, SISTEMA OPERATIVO, ARQUITECTURA, RAM (MB), CPU's"
	cadenaWAS=""

	echo $cadenaServ>> $dtempServ
	#echo $cadenaWAS>> $dtempWAS

#####Info servidor
#Hostname
	hn=$(hostname)
	hostName="$hn"

#IP
	ip=$(hostname -I | awk '{print $1}')
	ipadd="$ip"

#Sistema operativo
	os=$(whoami)
	
	os1="/$os/os_temp.txt"

	hostnamectl>> $os1

	sis=$(grep -r -i "Operating System" $os1)
	sistema="$sis"
	
	arqui=$(grep -r -i "Architecture" $os1)
	arquitectura="$arqui"

	rm $os1

#Memoria RAM

	let mem=$(grep MemTotal /proc/meminfo | awk '{print $2}')
	let ram=mem/1000
	
	memRam="$ram"

#No CPU's

	nCpu=$(grep -c ^processor /proc/cpuinfo)
	numcpu="$nCpu"

#Archivo temporal Sistema

	cadenaServ1="$hostName, $ipadd, $sistema, $arquitectura, $memRam, $numCpu"
	echo $cadenaServ1>> $dtempServ

##Localizar carpetas de los servicios WAS

	cmd1=$(find / -name "AppServer")

	cmd2=$(find / -name "Appserver")

	htserv=$(find / -name "HTTPServer")

	rutaHttp="$htserv"

	ruta1="$cmd1"
	ruta2="$cmd2"

#Solicitar usuario y contraseña de WAS
	echo ""
	echo "Iniciando recoleccion de datos"
	echo ""

	array_datos=($(find / -name "datos.txt"))

	let numD=${#array_datos[@]}
	let numD1=$numD-1

	r02="${array_datos[$numD1]}"

	array01=($(cat $r02))

	usWAS="${array01[0]}"
	uWAS="$usWAS"
	paWAS="${array01[1]}"
	pWAS="$paWAS"


