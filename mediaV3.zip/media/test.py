##AdminClusterManagement.listClusterMembers("ClusterTest")

#serverON = AdminControl.completeObjectName('node=mynode,type=Server,*')
#print serverON

print ""

objNameString = AdminControl.completeObjectName('WebSphere:type=Cluster,*') 
print objNameString
#print AdminControl.getAttribute(objNameString, 'processType')

print ""

objNameString1 = AdminControl.completeObjectName('WebSphere:type=NodeAgent,*') 
print objNameString1

print ""

objNameString2 = AdminControl.completeObjectName('WebSphere:type=Application,*') 
print objNameString2


